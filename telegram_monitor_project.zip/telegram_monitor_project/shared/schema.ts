import { z } from "zod";

// Predefined users configuration
export const PREDEFINED_USERS = {
  user_1: {
    id: "user_1",
    name: "المستخدم الأول",
    icon: "User",
    color: "#0088cc"
  },
  user_2: {
    id: "user_2",
    name: "المستخدم الثاني",
    icon: "UserCheck",
    color: "#28a745"
  },
  user_3: {
    id: "user_3",
    name: "المستخدم الثالث",
    icon: "UserCog",
    color: "#ffc107"
  },
  user_4: {
    id: "user_4",
    name: "المستخدم الرابع",
    icon: "UserX",
    color: "#dc3545"
  },
  user_5: {
    id: "user_5",
    name: "المستخدم الخامس",
    icon: "Users",
    color: "#6f42c1"
  }
} as const;

export type PredefinedUserId = keyof typeof PREDEFINED_USERS;

// Telegram Auth State
export const telegramAuthStateSchema = z.enum([
  "disconnected",
  "phone_required",
  "code_required",
  "password_required",
  "connected"
]);

export type TelegramAuthState = z.infer<typeof telegramAuthStateSchema>;

// User Session
export const userSessionSchema = z.object({
  userId: z.string(),
  telegramConnected: z.boolean(),
  authState: telegramAuthStateSchema,
  phone: z.string().optional(),
  username: z.string().optional(),
  firstName: z.string().optional(),
  lastName: z.string().optional()
});

export type UserSession = z.infer<typeof userSessionSchema>;

// Auto Reply Rule
export const autoReplyRuleSchema = z.object({
  id: z.string(),
  trigger: z.string().min(1, "الكلمة المفتاحية مطلوبة"),
  reply: z.string().min(1, "نص الرد مطلوب"),
  images: z.array(z.object({
    path: z.string(),
    name: z.string(),
    type: z.string()
  })).optional(),
  enabled: z.boolean().default(true),
  caseSensitive: z.boolean().default(false),
  exactMatch: z.boolean().default(false),
  triggerCount: z.number().default(0),
  createdAt: z.number(),
  lastTriggered: z.number().optional()
});

export type AutoReplyRule = z.infer<typeof autoReplyRuleSchema>;

export const insertAutoReplyRuleSchema = autoReplyRuleSchema.omit({
  id: true,
  triggerCount: true,
  createdAt: true,
  lastTriggered: true
});

export type InsertAutoReplyRule = z.infer<typeof insertAutoReplyRuleSchema>;

// Auto Reply System Settings
export const autoReplySettingsSchema = z.object({
  enabled: z.boolean().default(false),
  rules: z.array(autoReplyRuleSchema),
  excludedGroups: z.array(z.string())
});

export type AutoReplySettings = z.infer<typeof autoReplySettingsSchema>;

// Monitoring Keyword
export const monitoringKeywordSchema = z.object({
  id: z.string(),
  keyword: z.string().min(1),
  enabled: z.boolean().default(true),
  alertSound: z.boolean().default(true)
});

export type MonitoringKeyword = z.infer<typeof monitoringKeywordSchema>;

// Alert
export const alertSchema = z.object({
  id: z.string(),
  keyword: z.string(),
  group: z.string(),
  message: z.string(),
  fullMessage: z.string().optional(),
  timestamp: z.string(),
  sender: z.string(),
  senderUsername: z.string().optional(),
  messageTime: z.string(),
  messageId: z.number().optional(),
  chatId: z.number().optional(),
  isAutoReply: z.boolean().default(false),
  read: z.boolean().default(false)
});

export type Alert = z.infer<typeof alertSchema>;

// Telegram Group/Chat
export const telegramChatSchema = z.object({
  id: z.number(),
  title: z.string(),
  username: z.string().optional(),
  type: z.enum(["group", "supergroup", "channel", "private"]),
  membersCount: z.number().optional(),
  isMonitored: z.boolean().default(false)
});

export type TelegramChat = z.infer<typeof telegramChatSchema>;

// Stats
export const userStatsSchema = z.object({
  totalMessages: z.number().default(0),
  totalAlerts: z.number().default(0),
  autoReplies: z.number().default(0),
  activeGroups: z.number().default(0),
  uptime: z.string().optional()
});

export type UserStats = z.infer<typeof userStatsSchema>;

// WebSocket Message Types
export const wsMessageTypeSchema = z.enum([
  "auth_state",
  "new_alert",
  "stats_update",
  "log_update",
  "auto_reply_triggered",
  "connection_status"
]);

export type WsMessageType = z.infer<typeof wsMessageTypeSchema>;

export const wsMessageSchema = z.object({
  type: wsMessageTypeSchema,
  data: z.any()
});

export type WsMessage = z.infer<typeof wsMessageSchema>;

// API Response types
export interface ApiResponse<T = unknown> {
  success: boolean;
  message?: string;
  data?: T;
}

// Form schemas for validation
export const phoneFormSchema = z.object({
  phone: z.string().min(10, "رقم الهاتف يجب أن يكون 10 أرقام على الأقل")
});

export const codeFormSchema = z.object({
  code: z.string().length(5, "كود التحقق يجب أن يكون 5 أرقام")
});

export const passwordFormSchema = z.object({
  password: z.string().min(1, "كلمة المرور مطلوبة")
});

export const keywordFormSchema = z.object({
  keyword: z.string().min(1, "الكلمة المفتاحية مطلوبة")
});

export const autoReplyFormSchema = z.object({
  trigger: z.string().min(1, "الكلمة المفتاحية مطلوبة"),
  reply: z.string().min(1, "نص الرد مطلوب"),
  caseSensitive: z.boolean().default(false),
  exactMatch: z.boolean().default(false)
});

export type PhoneFormData = z.infer<typeof phoneFormSchema>;
export type CodeFormData = z.infer<typeof codeFormSchema>;
export type PasswordFormData = z.infer<typeof passwordFormSchema>;
export type KeywordFormData = z.infer<typeof keywordFormSchema>;
export type AutoReplyFormData = z.infer<typeof autoReplyFormSchema>;
