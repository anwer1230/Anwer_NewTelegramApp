import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PREDEFINED_USERS, type PredefinedUserId } from "@shared/schema";
import { User, UserCheck, UserCog, UserX, Users, MessageCircle, Zap, Shield } from "lucide-react";

interface UserSelectionProps {
  onSelectUser: (userId: PredefinedUserId) => void;
  connectedUsers?: Set<string>;
}

const iconMap: Record<string, React.ElementType> = {
  User,
  UserCheck,
  UserCog,
  UserX,
  Users,
};

export function UserSelection({ onSelectUser, connectedUsers = new Set() }: UserSelectionProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col" dir="rtl">
      {/* Hero Header */}
      <div className="gradient-telegram text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <MessageCircle className="w-12 h-12" />
            <h1 className="text-4xl font-bold">نظام مراقبة تيليجرام</h1>
          </div>
          <p className="text-xl opacity-90 mb-8">
            مراقبة المحادثات والرد التلقائي الذكي لجميع مجموعاتك
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              <span>مراقبة آمنة</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5" />
              <span>ردود فورية</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              <span>دعم متعدد المستخدمين</span>
            </div>
          </div>
        </div>
      </div>

      {/* User Selection Grid */}
      <div className="flex-1 py-12 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-semibold text-center mb-8 text-foreground">
            اختر حسابك للمتابعة
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(PREDEFINED_USERS).map(([id, user]) => {
              const IconComponent = iconMap[user.icon] || User;
              const isConnected = connectedUsers.has(id);
              
              return (
                <Card 
                  key={id} 
                  className="overflow-visible cursor-pointer transition-all duration-200 hover-elevate active-elevate-2"
                  data-testid={`card-user-${id}`}
                >
                  <CardHeader className="flex flex-row items-center gap-4 pb-2">
                    <div 
                      className="w-14 h-14 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: user.color + "20" }}
                    >
                      <IconComponent 
                        className="w-7 h-7" 
                        style={{ color: user.color }}
                      />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-lg">{user.name}</CardTitle>
                      <CardDescription className="flex items-center gap-2 mt-1">
                        {isConnected ? (
                          <Badge variant="default" className="bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20">
                            <span className="w-2 h-2 rounded-full bg-green-500 mr-1 animate-pulse" />
                            متصل
                          </Badge>
                        ) : (
                          <Badge variant="secondary">
                            غير متصل
                          </Badge>
                        )}
                      </CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-2">
                    <Button 
                      className="w-full"
                      style={{ 
                        backgroundColor: user.color,
                        borderColor: user.color
                      }}
                      onClick={() => onSelectUser(id as PredefinedUserId)}
                      data-testid={`button-select-${id}`}
                    >
                      <span>دخول</span>
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Features Section */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <MessageCircle className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">مراقبة شاملة</h3>
              <p className="text-muted-foreground">
                راقب جميع مجموعاتك ومحادثاتك في مكان واحد
              </p>
            </div>
            <div className="text-center p-6">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/10 flex items-center justify-center">
                <Zap className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-lg font-semibold mb-2">رد تلقائي ذكي</h3>
              <p className="text-muted-foreground">
                أنشئ قواعد للرد التلقائي على الرسائل بالنصوص والصور
              </p>
            </div>
            <div className="text-center p-6">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Shield className="w-8 h-8 text-purple-500" />
              </div>
              <h3 className="text-lg font-semibold mb-2">تنبيهات فورية</h3>
              <p className="text-muted-foreground">
                احصل على تنبيهات مباشرة عند ذكر كلماتك المفتاحية
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-6 border-t border-border">
        <div className="text-center text-sm text-muted-foreground">
          نظام مراقبة تيليجرام - جميع الحقوق محفوظة
        </div>
      </footer>
    </div>
  );
}
