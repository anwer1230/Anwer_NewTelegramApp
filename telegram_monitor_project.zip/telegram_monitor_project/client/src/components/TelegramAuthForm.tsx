import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { 
  phoneFormSchema, 
  codeFormSchema, 
  passwordFormSchema,
  type PhoneFormData,
  type CodeFormData,
  type PasswordFormData,
  type TelegramAuthState
} from "@shared/schema";
import { Phone, Key, Lock, Loader2, CheckCircle, MessageCircle, AlertCircle } from "lucide-react";

interface TelegramAuthFormProps {
  authState: TelegramAuthState;
  onSubmitPhone: (phone: string) => Promise<void>;
  onSubmitCode: (code: string) => Promise<void>;
  onSubmitPassword: (password: string) => Promise<void>;
  onDisconnect?: () => Promise<void>;
  isLoading?: boolean;
  error?: string | null;
  userName?: string;
}

export function TelegramAuthForm({
  authState,
  onSubmitPhone,
  onSubmitCode,
  onSubmitPassword,
  onDisconnect,
  isLoading = false,
  error,
  userName
}: TelegramAuthFormProps) {
  const [submitLoading, setSubmitLoading] = useState(false);

  const phoneForm = useForm<PhoneFormData>({
    resolver: zodResolver(phoneFormSchema),
    defaultValues: { phone: "" }
  });

  const codeForm = useForm<CodeFormData>({
    resolver: zodResolver(codeFormSchema),
    defaultValues: { code: "" }
  });

  const passwordForm = useForm<PasswordFormData>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: { password: "" }
  });

  const handlePhoneSubmit = async (data: PhoneFormData) => {
    setSubmitLoading(true);
    try {
      await onSubmitPhone(data.phone);
    } finally {
      setSubmitLoading(false);
    }
  };

  const handleCodeSubmit = async (data: CodeFormData) => {
    setSubmitLoading(true);
    try {
      await onSubmitCode(data.code);
    } finally {
      setSubmitLoading(false);
    }
  };

  const handlePasswordSubmit = async (data: PasswordFormData) => {
    setSubmitLoading(true);
    try {
      await onSubmitPassword(data.password);
    } finally {
      setSubmitLoading(false);
    }
  };

  const loading = isLoading || submitLoading;

  // Connected state
  if (authState === "connected") {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/10 flex items-center justify-center">
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
          <CardTitle className="text-xl">متصل بتيليجرام</CardTitle>
          {userName && (
            <CardDescription className="text-base">
              مرحباً، {userName}
            </CardDescription>
          )}
        </CardHeader>
        {onDisconnect && (
          <CardContent>
            <Button 
              variant="outline" 
              className="w-full" 
              onClick={onDisconnect}
              disabled={loading}
              data-testid="button-disconnect"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
              قطع الاتصال
            </Button>
          </CardContent>
        )}
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full gradient-telegram flex items-center justify-center">
          <MessageCircle className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="text-xl">الاتصال بتيليجرام</CardTitle>
        <CardDescription>
          {authState === "phone_required" && "أدخل رقم هاتفك المسجل في تيليجرام"}
          {authState === "code_required" && "أدخل كود التحقق المرسل إليك"}
          {authState === "password_required" && "أدخل كلمة مرور التحقق بخطوتين"}
          {authState === "disconnected" && "أدخل رقم هاتفك للبدء"}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Phone Form */}
        {(authState === "disconnected" || authState === "phone_required") && (
          <Form {...phoneForm}>
            <form onSubmit={phoneForm.handleSubmit(handlePhoneSubmit)} className="space-y-4">
              <FormField
                control={phoneForm.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم الهاتف</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          {...field}
                          type="tel"
                          placeholder="+966512345678"
                          className="pr-10 text-left"
                          dir="ltr"
                          disabled={loading}
                          data-testid="input-phone"
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                className="w-full" 
                disabled={loading}
                data-testid="button-submit-phone"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
                إرسال كود التحقق
              </Button>
            </form>
          </Form>
        )}

        {/* Code Form */}
        {authState === "code_required" && (
          <Form {...codeForm}>
            <form onSubmit={codeForm.handleSubmit(handleCodeSubmit)} className="space-y-4">
              <FormField
                control={codeForm.control}
                name="code"
                render={({ field }) => (
                  <FormItem className="flex flex-col items-center">
                    <FormLabel>كود التحقق</FormLabel>
                    <FormControl>
                      <InputOTP 
                        maxLength={5} 
                        value={field.value}
                        onChange={field.onChange}
                        disabled={loading}
                        data-testid="input-code"
                      >
                        <InputOTPGroup dir="ltr">
                          <InputOTPSlot index={0} />
                          <InputOTPSlot index={1} />
                          <InputOTPSlot index={2} />
                          <InputOTPSlot index={3} />
                          <InputOTPSlot index={4} />
                        </InputOTPGroup>
                      </InputOTP>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                className="w-full" 
                disabled={loading}
                data-testid="button-submit-code"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
                تحقق
              </Button>
            </form>
          </Form>
        )}

        {/* Password Form */}
        {authState === "password_required" && (
          <Form {...passwordForm}>
            <form onSubmit={passwordForm.handleSubmit(handlePasswordSubmit)} className="space-y-4">
              <FormField
                control={passwordForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>كلمة مرور التحقق بخطوتين</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          {...field}
                          type="password"
                          placeholder="••••••••"
                          className="pr-10"
                          disabled={loading}
                          data-testid="input-password"
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                className="w-full" 
                disabled={loading}
                data-testid="button-submit-password"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
                تسجيل الدخول
              </Button>
            </form>
          </Form>
        )}

        {/* Progress Indicator */}
        <div className="flex items-center justify-center gap-2 pt-4">
          <div className={`w-3 h-3 rounded-full transition-colors ${
            authState !== "disconnected" ? "bg-primary" : "bg-muted"
          }`} />
          <div className={`w-8 h-0.5 transition-colors ${
            authState === "code_required" || authState === "password_required" || authState === "connected" 
              ? "bg-primary" : "bg-muted"
          }`} />
          <div className={`w-3 h-3 rounded-full transition-colors ${
            authState === "code_required" || authState === "password_required" || authState === "connected"
              ? "bg-primary" : "bg-muted"
          }`} />
          <div className={`w-8 h-0.5 transition-colors ${
            authState === "password_required" || authState === "connected" ? "bg-primary" : "bg-muted"
          }`} />
          <div className={`w-3 h-3 rounded-full transition-colors ${
            authState === "connected" ? "bg-green-500" : "bg-muted"
          }`} />
        </div>
      </CardContent>
    </Card>
  );
}
